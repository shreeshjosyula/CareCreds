package com.example.carecreds.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.carecreds.R;
import com.example.carecreds.Utils.SharedPrefsUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private CheckBox rememberMeCheckBox;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        removeStatusBar();

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        initializeViews();
        setClickListeners();
    }

    private void initializeViews() {
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        rememberMeCheckBox = findViewById(R.id.rememberMeCheckBox);
        rememberMeCheckBox.setVisibility(View.GONE);
    }

    private void setClickListeners() {
        findViewById(R.id.SignUpPageNav).setOnClickListener(v -> openSignUpPage());
        findViewById(R.id.loginButton).setOnClickListener(v -> loginUser());
        findViewById(R.id.forgotPasswordTextView).setOnClickListener(v -> showPasswordResetToast());
    }

    private void openSignUpPage() {
        Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
        startActivity(intent);
    }

    private void loginUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (validateInputs(email, password)) {
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            checkUserTypeAndProceed(email);
                        } else {
                            Toast.makeText(LoginActivity.this, "Error Occurred! Contact Us!", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private boolean validateInputs(String email, String password) {
        if (email.isEmpty()) {
            emailEditText.setError("Email is required");
            Toast.makeText(LoginActivity.this, "Email is required!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!isValidEmail(email)) {
            emailEditText.setError("Invalid email format");
            Toast.makeText(LoginActivity.this, "Please enter a valid email address!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password.isEmpty()) {
            passwordEditText.setError("Password is required");
            Toast.makeText(LoginActivity.this, "Password is required!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void checkUserTypeAndProceed(String email) {
            db.collection("userType").document(email).get().addOnCompleteListener(task1 -> {
                if (task1.isSuccessful()) {
                    if (task1.getResult().get("accountType") == null) {
                        Toast.makeText(LoginActivity.this, "Please complete your profile!", Toast.LENGTH_SHORT).show();
                        SharedPrefsUtil.saveString(LoginActivity.this, "email", email);
                        Intent intent = new Intent(LoginActivity.this, UserTypeActivity.class);
                        startActivity(intent);
                    }
                    if (task1.getResult().get("accountType").equals("client")) {
                        checkClientDetails("Client", email);
                    } else {
                        checkClientDetails("Volunteer", email);
                    }
                }
            });
    }

    private void checkClientDetails(String CollectionName, String email) {
        db.collection(CollectionName).document(email).get().addOnCompleteListener(task2 -> {
            if (task2.isSuccessful()) {
                SharedPrefsUtil.saveString(LoginActivity.this, "email", email);
                if (task2.getResult().get("fullName") == null) {
                    Toast.makeText(LoginActivity.this, "Please complete your profile!", Toast.LENGTH_SHORT).show();
                    if (CollectionName.equals("Client")) {
                        Intent intent = new Intent(LoginActivity.this, RegistrationActivity.class);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(LoginActivity.this, VolunteerDetailFormActivity.class);
                        startActivity(intent);
                    } ;
                } else {
                    handleSuccessfulLogin(CollectionName, email);
                }
            } else {
                Toast.makeText(LoginActivity.this, "Error! ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void handleSuccessfulLogin(String CollectionName, String email) {
        if (rememberMeCheckBox.isChecked()) {
            SharedPrefsUtil.saveBoolean(LoginActivity.this, "rememberMe", true);
        }

        if (CollectionName.equals("Client")) {
            SharedPrefsUtil.saveString(LoginActivity.this, "userType", "client");
            Intent intent = new Intent(LoginActivity.this, HomeClientActivity.class);
            startActivity(intent);
        } else {
            SharedPrefsUtil.saveString(LoginActivity.this, "userType", "volunteer");
            Intent intent = new Intent(LoginActivity.this, HomeVolunteerActivity.class);
            startActivity(intent);
        }

    }

    private void showPasswordResetToast() {
        String email = emailEditText.getText().toString().trim();
        if (email.isEmpty()) {
            emailEditText.setError("Email is required");
            Toast.makeText(LoginActivity.this, "Email is required!", Toast.LENGTH_SHORT).show();
            return;
        }
        mAuth.sendPasswordResetEmail(email)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(LoginActivity.this, "Password reset email sent to " + email, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "Failed to send reset email. Check your email or try again later.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private boolean isValidEmail(CharSequence email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void removeStatusBar() {
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }
}

