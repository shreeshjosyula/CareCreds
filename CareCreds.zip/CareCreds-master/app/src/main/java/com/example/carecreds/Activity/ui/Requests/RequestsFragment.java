package com.example.carecreds.Activity.ui.Requests;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.carecreds.Adapters.RequestAdapter;
import com.example.carecreds.Model.Request;
import com.example.carecreds.R;
import com.example.carecreds.Utils.SharedPrefsUtil;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class RequestsFragment extends Fragment {


    public RequestsFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_requests, container, false);

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String userEmail = SharedPrefsUtil.getString(requireContext(), "email", "");
        CollectionReference requestsCollectionRef = db.collection("Request");
        RecyclerView recyclerView = view.findViewById(R.id.requests_recycler_view);

        Query userRequestsQuery = requestsCollectionRef.whereEqualTo("volunteerEmail", userEmail);
        userRequestsQuery.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                QuerySnapshot querySnapshot = task.getResult();
                if (querySnapshot != null && !querySnapshot.isEmpty()) {
                    List<Request> userRequestsList = new ArrayList<>();

                    for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                        Request request = document.toObject(Request.class);
                        if (request != null) {
                            request.setRequestId(document.getId());
                            userRequestsList.add(request);
                        }
                    }
                    RequestAdapter adapter = new RequestAdapter(requireContext(), userRequestsList);
                    recyclerView.setLayoutManager(new LinearLayoutManager(requireContext())); // Or use GridLayoutManager if needed
                    recyclerView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(requireContext(), "No requests found", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(requireContext(), "Error getting documents.", Toast.LENGTH_SHORT).show();
            }
        });
        return view;
    }
}