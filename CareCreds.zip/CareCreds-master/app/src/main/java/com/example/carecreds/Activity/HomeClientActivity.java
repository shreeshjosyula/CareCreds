package com.example.carecreds.Activity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import com.example.carecreds.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.carecreds.databinding.ActivityHomeClientBinding;

public class HomeClientActivity extends AppCompatActivity {

    private ActivityHomeClientBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#2BB7EC")));

        // Disable the Up button
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(false);
        }
        binding = ActivityHomeClientBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_services, R.id.navigation_all_volunteers, R.id.navigation_enrolled_volunteers, R.id.navigation_profile)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_home_client);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController);

//        getSupportFragmentManager().addOnBackStackChangedListener(() -> {
//            Fragment currentFragment = getCurrentFragment();
//            if (currentFragment instanceof EditProfileFragment) {
//                setActionBarMenu(R.menu.edit_profile_menu);
//            }
//        });
    }
//    private Fragment getCurrentFragment() {
//        return getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_activity_home_client);
//    }


}